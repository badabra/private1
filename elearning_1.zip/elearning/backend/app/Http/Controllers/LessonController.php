<?php
namespace App\Http\Controllers;

use App\Models\Course;
use App\Models\Lesson;
use App\Models\Module;
use Illuminate\Http\Request;

class LessonController extends Controller
{
    // POST /api/formateur/modules/{module}/lessons
    public function store(Request $request, Module $module)
    {
        $this->authorizeModule($request, $module);

        $data = $request->validate([
            'titre'     => 'required|string|max:255',
            'contenu'   => 'nullable|string',
            'type'      => 'sometimes|in:texte,video,pdf',
            'url_media' => 'nullable|string|max:255',
            'ordre'     => 'sometimes|integer|min:0',
        ]);

        $lesson = $module->lessons()->create([
            'titre'     => $data['titre'],
            'contenu'   => $data['contenu'] ?? null,
            'type'      => $data['type'] ?? 'texte',
            'url_media' => $data['url_media'] ?? null,
            'ordre'     => $data['ordre'] ?? ((int) $module->lessons()->max('ordre') + 1),
        ]);

        return response()->json($lesson, 201);
    }

    // PUT /api/formateur/lessons/{lesson}
    public function update(Request $request, Lesson $lesson)
    {
        $this->authorizeModule($request, $lesson->module);

        $data = $request->validate([
            'titre'     => 'sometimes|string|max:255',
            'contenu'   => 'nullable|string',
            'type'      => 'sometimes|in:texte,video,pdf',
            'url_media' => 'nullable|string|max:255',
            'ordre'     => 'sometimes|integer|min:0',
        ]);

        $lesson->update($data);
        return response()->json($lesson);
    }

    // DELETE /api/formateur/lessons/{lesson}
    public function destroy(Request $request, Lesson $lesson)
    {
        $this->authorizeModule($request, $lesson->module);
        $lesson->delete();
        return response()->json(['message' => 'Leçon supprimée.']);
    }

    private function authorizeModule(Request $request, Module $module): void
    {
        $user = $request->user();
        $course = $module->course;
        if ($user->role !== 'admin' && $course->formateur_id !== $user->id) {
            abort(403, "Vous ne gérez pas ce cours.");
        }
    }
}
