<?php
namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        User::firstOrCreate(
            ['email' => 'admin@elearning.test'],
            ['name' => 'Admin', 'password' => Hash::make('Admin1234!'), 'role' => 'admin', 'is_approved' => true]
        );

        // Formateur déjà approuvé (pour tester la connexion formateur normale)
        User::firstOrCreate(
            ['email' => 'formateur@elearning.test'],
            ['name' => 'Formateur Demo', 'password' => Hash::make('Form1234!'), 'role' => 'formateur', 'is_approved' => true]
        );

        // Formateur EN ATTENTE (pour démontrer l'approbation par l'admin)
        User::firstOrCreate(
            ['email' => 'formateur2@elearning.test'],
            ['name' => 'Formateur En Attente', 'password' => Hash::make('Form1234!'), 'role' => 'formateur', 'is_approved' => false]
        );

        User::firstOrCreate(
            ['email' => 'etudiant@elearning.test'],
            ['name' => 'Etudiant Demo', 'password' => Hash::make('Etud1234!'), 'role' => 'etudiant', 'is_approved' => true]
        );
    }
}
